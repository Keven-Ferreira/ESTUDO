console.log('vai começar...')
for (var c=1; c<=4; c++){
    console.log('for '+c)
}
console.log('Fim!')