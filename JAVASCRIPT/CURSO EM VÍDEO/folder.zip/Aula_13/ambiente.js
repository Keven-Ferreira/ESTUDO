/* var c = 1;
while(c <= 500){
    console.log(`Passo ${c}`);
    c++
} */

var c = 1;
do{
    console.log(`Passo ${c}`);
    c++
}while(c <= 06)
